﻿namespace Module1
{
    partial class Module1Ex1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtName = new TextBox();
            btnWelcome = new Button();
            btnGoodbye = new Button();
            lblGreeting = new Label();
            btnExit = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(15, 31);
            label1.Name = "label1";
            label1.Size = new Size(118, 28);
            label1.TabIndex = 0;
            label1.Text = "Enter Name:";
            // 
            // txtName
            // 
            txtName.Location = new Point(139, 31);
            txtName.Name = "txtName";
            txtName.Size = new Size(259, 34);
            txtName.TabIndex = 1;
            // 
            // btnWelcome
            // 
            btnWelcome.Location = new Point(125, 90);
            btnWelcome.Name = "btnWelcome";
            btnWelcome.Size = new Size(107, 36);
            btnWelcome.TabIndex = 2;
            btnWelcome.Text = "Welcome";
            btnWelcome.UseVisualStyleBackColor = true;
            btnWelcome.Click += btnWelcome_Click;
            // 
            // btnGoodbye
            // 
            btnGoodbye.Location = new Point(277, 90);
            btnGoodbye.Name = "btnGoodbye";
            btnGoodbye.Size = new Size(107, 36);
            btnGoodbye.TabIndex = 3;
            btnGoodbye.Text = "Goodbye";
            btnGoodbye.UseVisualStyleBackColor = true;
            btnGoodbye.Click += btnGoodbye_Click;
            // 
            // lblGreeting
            // 
            lblGreeting.BorderStyle = BorderStyle.Fixed3D;
            lblGreeting.Location = new Point(124, 149);
            lblGreeting.Name = "lblGreeting";
            lblGreeting.Size = new Size(260, 28);
            lblGreeting.TabIndex = 4;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(183, 198);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(107, 36);
            btnExit.TabIndex = 5;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // Module1Ex1
            // 
            AutoScaleDimensions = new SizeF(11F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(416, 248);
            Controls.Add(btnExit);
            Controls.Add(lblGreeting);
            Controls.Add(btnGoodbye);
            Controls.Add(btnWelcome);
            Controls.Add(txtName);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 12F);
            Margin = new Padding(4);
            Name = "Module1Ex1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Module 1 - Example 1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtName;
        private Button btnWelcome;
        private Button btnGoodbye;
        private Label lblGreeting;
        private Button btnExit;
    }
}