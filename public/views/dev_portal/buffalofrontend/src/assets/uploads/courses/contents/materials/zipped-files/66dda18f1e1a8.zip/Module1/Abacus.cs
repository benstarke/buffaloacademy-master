﻿/*
 * Project:         Module 1; Example 2
 * Date:            August 2024
 * Developed By:    LV
 * Class Name:      Abacus
 * Description:     Business Logic class for a simple calculator
 * Purpose:         Demonstrate examples of methods
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module1
{
    static class Abacus
    {
        // Add two numbers and return the result

        public static int Add(int num1, int num2)
        {
            return num1 + num2;
        }

        // Subtract one number from another and return the result

        public static int Subtract(int num1, int num2)
        {
            return num1 - num2;
        }

        // Multiply two numbers and return the result

        public static int Multiply(int num1, int num2)
        {
            return num1 * num2;
        }
    }
}
