﻿namespace Module1
{
    partial class Module1Ex2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtOne = new TextBox();
            txtTwo = new TextBox();
            btnAdd = new Button();
            btnSubtract = new Button();
            btnMultiply = new Button();
            lblResult = new Label();
            btnExit = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(16, 27);
            label1.Name = "label1";
            label1.Size = new Size(174, 28);
            label1.TabIndex = 0;
            label1.Text = "Enter two integers:";
            // 
            // txtOne
            // 
            txtOne.Location = new Point(196, 27);
            txtOne.Name = "txtOne";
            txtOne.Size = new Size(95, 34);
            txtOne.TabIndex = 1;
            txtOne.TextAlign = HorizontalAlignment.Right;
            // 
            // txtTwo
            // 
            txtTwo.Location = new Point(309, 27);
            txtTwo.Name = "txtTwo";
            txtTwo.Size = new Size(95, 34);
            txtTwo.TabIndex = 2;
            txtTwo.TextAlign = HorizontalAlignment.Right;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(83, 74);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(95, 37);
            btnAdd.TabIndex = 3;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSubtract
            // 
            btnSubtract.Location = new Point(196, 74);
            btnSubtract.Name = "btnSubtract";
            btnSubtract.Size = new Size(95, 37);
            btnSubtract.TabIndex = 4;
            btnSubtract.Text = "Subtract";
            btnSubtract.UseVisualStyleBackColor = true;
            btnSubtract.Click += btnSubtract_Click;
            // 
            // btnMultiply
            // 
            btnMultiply.Location = new Point(309, 74);
            btnMultiply.Name = "btnMultiply";
            btnMultiply.Size = new Size(95, 37);
            btnMultiply.TabIndex = 5;
            btnMultiply.Text = "Multiply";
            btnMultiply.UseVisualStyleBackColor = true;
            btnMultiply.Click += btnMultiply_Click;
            // 
            // lblResult
            // 
            lblResult.BorderStyle = BorderStyle.Fixed3D;
            lblResult.Location = new Point(196, 123);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(207, 32);
            lblResult.TabIndex = 6;
            lblResult.TextAlign = ContentAlignment.MiddleRight;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(308, 167);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(95, 43);
            btnExit.TabIndex = 7;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // Module1Ex2
            // 
            AutoScaleDimensions = new SizeF(11F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(419, 222);
            Controls.Add(btnExit);
            Controls.Add(lblResult);
            Controls.Add(btnMultiply);
            Controls.Add(btnSubtract);
            Controls.Add(btnAdd);
            Controls.Add(txtTwo);
            Controls.Add(txtOne);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 12F);
            Margin = new Padding(4);
            Name = "Module1Ex2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Module 1 - Example 2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtOne;
        private TextBox txtTwo;
        private Button btnAdd;
        private Button btnSubtract;
        private Button btnMultiply;
        private Label lblResult;
        private Button btnExit;
    }
}