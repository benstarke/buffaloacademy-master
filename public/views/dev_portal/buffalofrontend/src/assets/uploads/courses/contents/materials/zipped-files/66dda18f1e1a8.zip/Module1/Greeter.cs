﻿/*
 * Project:         Module 1; Example 1
 * Date:            August 2024
 * Developed By:    LV
 * Class Name:      Greeter
 * Description:     Business Logic class for displaying greetings
 * Purpose:         Demonstrate examples of simple methods
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module1
{
    static class Greeter
    {
        // method with no parameters
        public static string DisplayHello()
        {
            return "Hello";
        }

        // method with one parameter
        // concatenates or joins "Goodbye" to the passed argument and returns the resulting string

        public static string DisplayGoodbye(string name)
        {
            //return "Goodbye, " + strName;

            return $"Goodbye, {name}";
        }
    }
}
