﻿/*
 * Project:         Module 1; Example 1
 * Date:            August 2024
 * Developed By:    LV
 * Class Name:      Module1Ex1
 * Description:     Presentation Layer class for displaying greetings
 * Purpose:         Demonstrate how to use the methods of a static class
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Module1
{
    public partial class Module1Ex1 : Form
    {
        public Module1Ex1()
        {
            InitializeComponent();
        }

        private void btnWelcome_Click(object sender, EventArgs e)
        {
            // call the DisplayHello method

            lblGreeting.Text = Greeter.DisplayHello();
        }

        private void btnGoodbye_Click(object sender, EventArgs e)
        {
            // call the DisplayGoodbye method

            lblGreeting.Text = Greeter.DisplayGoodbye(txtName.Text);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // close the form

            this.Close();
        }
    }
}
